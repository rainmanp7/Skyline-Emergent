import torch
from torch import nn

class MetaLearner(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(MetaLearner, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, output_size)
        self.relu = nn.ReLU()
        self.softmax = nn.Softmax(dim=0)  # Add softmax activation

    def forward(self, x):
        x = self.relu(self.fc1(x))
        x = self.fc2(x)
        x = self.softmax(x)  # Apply softmax to output
        return x

class DialogueSystem:
    def __init__(self, meta_learner, options_file="options.txt"):
        self.meta_learner = meta_learner
        self.options = self.load_options(options_file)

    def load_options(self, options_file):
        with open(options_file, "r") as file:
            options = [line.strip() for line in file.readlines()]
        return options

    def ask_question(self, question, performance_metrics):
        # Convert question and performance metrics to input tensor
        input_tensor = torch.tensor(performance_metrics, dtype=torch.float32)
        response = self.meta_learner(input_tensor)
        
        # Map response to human-readable suggestions
        selected_option = self.options[torch.argmax(response).item()]
        return selected_option