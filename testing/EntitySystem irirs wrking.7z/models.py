import torch
from torch import nn

class SimpleRNN(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, dropout_rate=0.5):
        super(SimpleRNN, self).__init__()
        self.rnn = nn.RNN(input_size, hidden_size, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        # Add a time dimension (batch_size, sequence_length=1, input_size)
        x = x.unsqueeze(1)
        h_0 = torch.zeros(1, x.size(0), self.rnn.hidden_size)
        out, _ = self.rnn(x, h_0)
        out = self.fc(out[:, -1, :])
        return out

class SimpleCNN(nn.Module):
    def __init__(self, input_channels, output_size, dropout_rate=0.5):
        super(SimpleCNN, self).__init__()
        self.conv1 = nn.Conv2d(input_channels, 16, kernel_size=2, stride=1, padding=1)
        self.relu = nn.ReLU()
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2, padding=0)
        self.fc = nn.Linear(16 * 1 * 1, output_size)  # Adjusted for 2x2 input
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        # Reshape input to [batch_size, 1, 2, 2]
        x = x.view(-1, 1, 2, 2)
        x = self.pool(self.relu(self.conv1(x)))
        x = x.view(-1, 16 * 1 * 1)  # Flatten the tensor
        x = self.dropout(x)
        x = self.fc(x)
        return x

class SimpleSNN(nn.Module):
    def __init__(self, input_size, output_size, num_steps, dropout_rate=0.5):
        super(SimpleSNN, self).__init__()
        self.num_steps = num_steps
        self.fc1 = nn.Linear(input_size, 50)  # Hidden layer
        self.fc2 = nn.Linear(50, output_size)  # Output layer
        self.spike_threshold = 1.0  # Threshold for spiking
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        batch_size = x.size(0)
        # Repeat input across time steps
        x = x.unsqueeze(1).repeat(1, self.num_steps, 1)  # Shape: [batch_size, num_steps, input_size]
        
        # Initialize membrane potential
        v_mem = torch.zeros(batch_size, 50)  # Membrane potential for 50 hidden neurons
        
        # Simulate spiking over time steps
        for step in range(self.num_steps):
            cur = self.fc1(x[:, step])  # Input at current time step
            v_mem += cur  # Update membrane potential
            spikes = (v_mem > self.spike_threshold).float()  # Generate spikes
            v_mem = v_mem * (1 - spikes)  # Reset membrane potential for spiked neurons
        
        # Use final membrane potential for classification
        out = self.fc2(v_mem)
        return out

class Entity(nn.Module):
    def __init__(self, rnn, cnn, snn):
        super(Entity, self).__init__()
        self.rnn = rnn
        self.cnn = cnn
        self.snn = snn

    def forward(self, x):
        rnn_output = self.rnn(x)
        cnn_output = self.cnn(x)
        snn_output = self.snn(x)
        consensus = torch.mean(torch.stack([rnn_output, cnn_output, snn_output]), dim=0)
        return consensus