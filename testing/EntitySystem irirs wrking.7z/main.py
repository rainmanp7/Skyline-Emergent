import torch
from torch import nn, optim
from torch.utils.data import DataLoader
from models import SimpleRNN, SimpleCNN, SimpleSNN, Entity
from dataset import load_iris_data
from train import train, test
from dialogue_system import MetaLearner, DialogueSystem

def main():
    # Load dataset
    train_loader, test_loader = load_iris_data()

    # Initialize models
    input_size = 4  # Iris has 4 features
    hidden_size = 10
    output_size = 3  # 3 classes
    num_steps = 10
    dropout_rate = 0.5

    rnn = SimpleRNN(input_size, hidden_size, output_size, dropout_rate=dropout_rate)
    cnn = SimpleCNN(input_channels=1, output_size=output_size, dropout_rate=dropout_rate)
    snn_model = SimpleSNN(input_size, output_size, num_steps, dropout_rate=dropout_rate)
    models = [rnn, cnn, snn_model]

    # Define loss function and optimizers
    criterion = nn.CrossEntropyLoss()
    optimizers = [
        optim.Adam(rnn.parameters(), lr=0.001),
        optim.Adam(cnn.parameters(), lr=0.001),
        optim.Adam(snn_model.parameters(), lr=0.001)
    ]

    # Initialize Meta-Learner and Dialogue System
    meta_learner = MetaLearner(input_size=5, hidden_size=10, output_size=len(DialogueSystem([]).options))
    dialogue_system = DialogueSystem(meta_learner)

    # Train models
    val_accuracy = train(models, train_loader, test_loader, optimizers, criterion, num_epochs=20)

    # Test models
    test_accuracy = test(models, test_loader)
    print(f'Final Test Accuracy: {test_accuracy:.2f}%')

    # Example question and performance metrics
    question = "What improvements should be made to the system?"
    performance_metrics = [test_accuracy, 0.5, 0.3, 0.2, 0.1]  # Example metrics

    # Get response from the system
    response = dialogue_system.ask_question(question, performance_metrics)
    print(f"The system recommends: {response}")

if __name__ == "__main__":
    main()