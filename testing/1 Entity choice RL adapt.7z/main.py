import torch
from torch import nn
from torch import optim
from torch.utils.data import DataLoader
from models import SimpleRNN, SimpleRNNWithAttention, SimpleCNN, SimpleSNN
from dataset import SyntheticDataset
from train import train, test
from dialogue_system import MetaLearner, DialogueSystem
from torch.optim.lr_scheduler import CyclicLR, StepLR, ReduceLROnPlateau

def initialize_optimizers(models, learning_rate, weight_decay=0.0):
    optimizers = [
        optim.Adam(models[0].parameters(), lr=learning_rate, weight_decay=weight_decay),
        optim.Adam(models[1].parameters(), lr=learning_rate, weight_decay=weight_decay),
        optim.Adam(models[2].parameters(), lr=learning_rate, weight_decay=weight_decay)
    ]
    return optimizers

def initialize_schedulers(optimizers, scheduler_type, **kwargs):
    schedulers = []
    for optimizer in optimizers:
        if scheduler_type == "CyclicLR":
            schedulers.append(CyclicLR(optimizer, **kwargs))
        elif scheduler_type == "StepLR":
            schedulers.append(StepLR(optimizer, **kwargs))
        elif scheduler_type == "ReduceLROnPlateau":
            schedulers.append(ReduceLROnPlateau(optimizer, **kwargs))
        else:
            schedulers.append(None)  # No scheduler
    return schedulers

class Entity:
    def __init__(self):
        self.input_size = 10
        self.hidden_size = 20
        self.output_size = 2
        self.num_steps = 10
        self.num_samples = 1000
        self.seq_len = 5
        self.cnn_input_size = 16
        self.batch_size = 32
        self.num_epochs = 35
        self.learning_rate = 0.001
        self.dropout_rate = 0.5

        # Log starting settings
        print("\n=== Starting Settings ===")
        self.print_settings()

    def print_settings(self):
        """Print the current settings of the entity."""
        print(f"input_size: {self.input_size}")
        print(f"hidden_size: {self.hidden_size}")
        print(f"output_size: {self.output_size}")
        print(f"num_steps: {self.num_steps}")
        print(f"num_samples: {self.num_samples}")
        print(f"seq_len: {self.seq_len}")
        print(f"cnn_input_size: {self.cnn_input_size}")
        print(f"batch_size: {self.batch_size}")
        print(f"num_epochs: {self.num_epochs}")
        print(f"learning_rate: {self.learning_rate}")
        print(f"dropout_rate: {self.dropout_rate}")
        print("=========================\n")

    def adjust_parameters(self, performance_metrics):
        """Adjust parameters based on performance metrics and log changes."""
        print("\n=== Adjusting Parameters ===")
        old_learning_rate = self.learning_rate
        old_num_epochs = self.num_epochs

        if performance_metrics[0] < 50:  # If accuracy is low
            self.learning_rate *= 1.1
            self.num_epochs += 5
        elif performance_metrics[0] > 90:  # If accuracy is high
            self.learning_rate *= 0.9
            self.num_epochs -= 5

        # Log changes
        if old_learning_rate != self.learning_rate:
            print(f"Learning rate changed from {old_learning_rate} to {self.learning_rate}")
        if old_num_epochs != self.num_epochs:
            print(f"Number of epochs changed from {old_num_epochs} to {self.num_epochs}")
        print("===========================\n")

def main():
    entity = Entity()

    # Initialize models
    rnn = SimpleRNN(entity.input_size, entity.hidden_size, entity.output_size, dropout_rate=entity.dropout_rate)
    cnn = SimpleCNN(input_channels=1, output_size=entity.output_size, dropout_rate=entity.dropout_rate)
    snn_model = SimpleSNN(entity.input_size, entity.output_size, entity.num_steps, dropout_rate=entity.dropout_rate)
    models = [rnn, cnn, snn_model]

    # Create dataset and dataloaders
    train_dataset = SyntheticDataset(entity.num_samples, entity.input_size, entity.seq_len, entity.output_size, entity.cnn_input_size)
    val_dataset = SyntheticDataset(entity.num_samples // 5, entity.input_size, entity.seq_len, entity.output_size, entity.cnn_input_size)  # Validation set
    train_loader = DataLoader(train_dataset, batch_size=entity.batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=entity.batch_size, shuffle=False)

    # Define loss function and optimizers
    criterion = nn.CrossEntropyLoss()
    optimizers = initialize_optimizers(models, entity.learning_rate)
    schedulers = initialize_schedulers(optimizers, None)  # No scheduler initially

    # Initialize Meta-Learner and Dialogue System
    meta_learner = MetaLearner(input_size=5, hidden_size=10, output_size=len(DialogueSystem([]).options))
    dialogue_system = DialogueSystem(meta_learner)

    # Train models and get initial accuracy
    val_accuracy = train(models, train_loader, val_loader, optimizers, schedulers, criterion, entity.num_epochs)
    initial_accuracy = val_accuracy
    print(f'Initial Test Accuracy: {initial_accuracy:.2f}%')

    # Continue adjusting settings and retraining until a target accuracy is reached or max iterations
    max_iterations = 10  # Maximum number of iterations
    iteration = 0

    while iteration < max_iterations:
        iteration += 1
        print(f"\n=== Iteration {iteration} ===")

        # Test models
        test_accuracy = test(models, val_loader)
        print(f'Current Test Accuracy: {test_accuracy:.2f}%')

        # If accuracy exceeds initial value, stop
        if test_accuracy > initial_accuracy:
            print(f"Accuracy improved to {test_accuracy:.2f}%, which is above the initial accuracy of {initial_accuracy:.2f}%. Stopping.")
            break

        # Example question and performance metrics
        question = "What improvements should be made to the system?"
        performance_metrics = [test_accuracy, 0.5, 0.3, 0.2, 0.1]  # Example metrics

        # Get response from the system
        response = dialogue_system.ask_question(question, performance_metrics)
        print(f"The system recommends: {response}")

        # Apply the recommendation
        models, optimizers, schedulers = dialogue_system.apply_option(response, models, optimizers, schedulers, entity.learning_rate, entity.dropout_rate)

        # Adjust parameters based on performance
        entity.adjust_parameters(performance_metrics)

        # Retrain models with the adjusted configuration
        val_accuracy = train(models, train_loader, val_loader, optimizers, schedulers, criterion, entity.num_epochs)

    if iteration == max_iterations:
        print(f"Reached maximum iterations ({max_iterations}) without achieving the target accuracy.")

if __name__ == "__main__":
    main()