import torch
from torch import nn
from torch_geometric.nn import GCNConv

class SimpleRNN(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, dropout_rate=0.5):
        super(SimpleRNN, self).__init__()
        self.rnn = nn.RNN(input_size, hidden_size, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        h_0 = torch.zeros(1, x.size(0), self.rnn.hidden_size)
        out, _ = self.rnn(x, h_0)
        out = self.fc(out[:, -1, :])
        return out

class SimpleRNNWithAttention(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, num_heads=4, dropout_rate=0.5):
        super(SimpleRNNWithAttention, self).__init__()
        self.rnn = nn.RNN(input_size, hidden_size, batch_first=True)
        self.attention = nn.MultiheadAttention(hidden_size, num_heads, dropout=dropout_rate)
        self.fc = nn.Linear(hidden_size, output_size)
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        h_0 = torch.zeros(1, x.size(0), self.rnn.hidden_size)
        rnn_out, _ = self.rnn(x, h_0)  # RNN output: [batch_size, seq_len, hidden_size]
        
        # Reshape for MultiheadAttention (seq_len, batch_size, hidden_size)
        rnn_out = rnn_out.permute(1, 0, 2)
        attn_out, _ = self.attention(rnn_out, rnn_out, rnn_out)  # Apply self-attention
        attn_out = attn_out.permute(1, 0, 2)  # Reshape back to [batch_size, seq_len, hidden_size]
        
        # Use the last time step's output for classification
        out = self.fc(attn_out[:, -1, :])
        return out

class SimpleCNN(nn.Module):
    def __init__(self, input_channels, output_size, dropout_rate=0.5):
        super(SimpleCNN, self).__init__()
        self.conv1 = nn.Conv2d(input_channels, 16, kernel_size=3, stride=1, padding=1)
        self.relu = nn.ReLU()
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2, padding=0)
        self.fc = nn.Linear(16 * 8 * 8, output_size)
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        x = self.pool(self.relu(self.conv1(x)))
        x = x.view(-1, 16 * 8 * 8)
        x = self.dropout(x)
        x = self.fc(x)
        return x

class SimpleSNN(nn.Module):
    def __init__(self, input_size, output_size, num_steps, dropout_rate=0.5):
        super(SimpleSNN, self).__init__()
        self.num_steps = num_steps
        self.fc1 = nn.Linear(input_size, 50)
        self.fc2 = nn.Linear(50, output_size)
        self.spike_threshold = 1.0  # Threshold for spiking
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        batch_size = x.size(0)
        if len(x.size()) == 2:  # If input is [batch_size, input_size]
            x = x.unsqueeze(1).repeat(1, self.num_steps, 1)  # Add timestep dimension
        
        # Initialize membrane potential
        v_mem = torch.zeros(batch_size, 50)
        
        # Simulate spiking behavior
        for step in range(self.num_steps):
            cur = self.fc1(x[:, step])
            v_mem += cur
            spikes = (v_mem > self.spike_threshold).float()  # Generate spikes
            v_mem = v_mem * (1 - spikes)  # Reset membrane potential for spiked neurons
        
        out = self.fc2(v_mem)
        return out

class ExternalMemory(nn.Module):
    """A simple external memory module inspired by Neural Turing Machines (NTMs)."""
    def __init__(self, memory_size, memory_dim):
        super(ExternalMemory, self).__init__()
        self.memory = nn.Parameter(torch.randn(memory_size, memory_dim))  # Memory matrix
        self.memory_size = memory_size
        self.memory_dim = memory_dim

    def read(self, query):
        """Read from memory using a query vector."""
        # Compute attention weights over memory locations
        attn_weights = torch.softmax(torch.matmul(query, self.memory.t()), dim=-1)
        # Weighted sum of memory locations
        read_value = torch.matmul(attn_weights, self.memory)
        return read_value

    def write(self, query, value):
        """Write to memory using a query vector and a value."""
        # Compute attention weights over memory locations
        attn_weights = torch.softmax(torch.matmul(query, self.memory.t()), dim=-1)
        # Update memory with weighted value
        self.memory.data += torch.matmul(attn_weights.t(), value)

class EmergentSystemWithGNNandMANN(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, num_steps, dropout_rate=0.5, memory_size=10, memory_dim=20):
        super(EmergentSystemWithGNNandMANN, self).__init__()
        # Define three distinct networks
        self.rnn_entity = SimpleRNN(input_size, hidden_size, hidden_size, dropout_rate)
        self.cnn_entity = SimpleCNN(input_channels=1, output_size=hidden_size, dropout_rate=dropout_rate)
        self.snn_entity = SimpleSNN(input_size, hidden_size, num_steps, dropout_rate)
        
        # GNN layer for communication
        self.gnn_conv = GCNConv(hidden_size * 3, hidden_size * 3)
        
        # External memory module
        self.memory = ExternalMemory(memory_size, memory_dim)
        
        # Final output layer
        self.fc = nn.Linear(hidden_size * 3 + memory_dim, output_size)

    def forward(self, x):
        # Each entity processes the input independently
        rnn_output = self.rnn_entity(x)
        
        # Reshape input for CNN
        batch_size, seq_len, input_size = x.shape
        cnn_input = x.view(batch_size * seq_len, 1, int(input_size**0.5), int(input_size**0.5))
        cnn_output = self.cnn_entity(cnn_input)
        cnn_output = cnn_output.view(batch_size, seq_len, -1)
        
        snn_output = self.snn_entity(x[:, 0, :])
        
        # Combine outputs for GNN
        combined_outputs = torch.cat([rnn_output, cnn_output[:, -1, :], snn_output], dim=1)
        
        # Create a fully connected graph (all entities are connected to each other)
        edge_index = torch.tensor([[i, j] for i in range(batch_size) for j in range(batch_size)], dtype=torch.long).t().contiguous()
        
        # Apply GNN for communication
        communicated_outputs = self.gnn_conv(combined_outputs, edge_index)
        
        # Read from external memory
        memory_query = communicated_outputs  # Use GNN output as query
        memory_read = self.memory.read(memory_query)
        
        # Combine GNN output and memory read
        final_output = torch.cat([communicated_outputs, memory_read], dim=1)
        
        # Final output after communication and memory interaction
        out = self.fc(final_output)
        return out