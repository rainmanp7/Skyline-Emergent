from torch import optim

def initialize_optimizers(models, learning_rate, weight_decay=0.0):
    return [optim.Adam(model.parameters(), lr=learning_rate, weight_decay=weight_decay) for model in models]