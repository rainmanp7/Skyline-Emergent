from torch.optim.lr_scheduler import CyclicLR, StepLR, ReduceLROnPlateau

def initialize_schedulers(optimizers, scheduler_type, **kwargs):
    schedulers = []
    for optimizer in optimizers:
        if scheduler_type == "CyclicLR":
            # Disable cycle_momentum for Adam optimizer
            kwargs["cycle_momentum"] = False
            schedulers.append(CyclicLR(optimizer, **kwargs))
        elif scheduler_type == "StepLR":
            schedulers.append(StepLR(optimizer, **kwargs))
        elif scheduler_type == "ReduceLROnPlateau":
            schedulers.append(ReduceLROnPlateau(optimizer, **kwargs))
        else:
            schedulers.append(None)
    return schedulers