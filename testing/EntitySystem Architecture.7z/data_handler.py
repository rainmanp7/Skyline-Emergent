import torch
from torch.utils.data import Dataset, DataLoader

class SyntheticDataset(Dataset):
    def __init__(self, num_samples, input_size, seq_len, output_size, cnn_input_size):
        self.num_samples = num_samples
        self.input_size = input_size
        self.seq_len = seq_len
        self.output_size = output_size
        self.cnn_input_size = cnn_input_size
        self.data = torch.randn(num_samples, seq_len, input_size)
        self.cnn_data = torch.randn(num_samples, 1, cnn_input_size, cnn_input_size)
        self.labels = (torch.sum(self.data, dim=(1, 2)) > 0).long()

    def __len__(self):
        return self.num_samples

    def __getitem__(self, idx):
        return self.data[idx], self.cnn_data[idx], self.labels[idx]

class DataHandler:
    def __init__(self, num_samples, input_size, seq_len, output_size, cnn_input_size, batch_size):
        self.train_dataset = SyntheticDataset(num_samples, input_size, seq_len, output_size, cnn_input_size)
        self.val_dataset = SyntheticDataset(num_samples // 5, input_size, seq_len, output_size, cnn_input_size)
        self.train_loader = DataLoader(self.train_dataset, batch_size=batch_size, shuffle=True)
        self.val_loader = DataLoader(self.val_dataset, batch_size=batch_size, shuffle=False)