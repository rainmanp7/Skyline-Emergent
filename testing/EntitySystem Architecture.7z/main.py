import torch
from torch import nn, optim
from data_handler import DataHandler
from model_handler import ModelHandler
from trainer import Trainer
from tester import Tester
from dialogue_system import MetaLearner, DialogueSystem
from utils.optimizers import initialize_optimizers
from utils.schedulers import initialize_schedulers

def main():
    input_size = 10
    hidden_size = 20
    output_size = 2
    num_steps = 10
    num_samples = 1000
    seq_len = 5
    cnn_input_size = 16
    batch_size = 32
    num_epochs = 35
    learning_rate = 0.001
    dropout_rate = 0.5

    # Initialize DataHandler
    data_handler = DataHandler(num_samples, input_size, seq_len, output_size, cnn_input_size, batch_size)

    # Initialize ModelHandler with options_file
    model_handler = ModelHandler(input_size, hidden_size, output_size, num_steps, dropout_rate, options_file="options.txt")
    models = model_handler.get_models()

    # Define loss function, optimizers, and schedulers
    criterion = nn.CrossEntropyLoss()
    optimizers = initialize_optimizers(models, learning_rate)
    schedulers = initialize_schedulers(optimizers, None)

    # Initialize MetaLearner and DialogueSystem
    meta_learner = MetaLearner(input_size=5, hidden_size=10, output_size=len(DialogueSystem([], input_size, hidden_size, output_size).options))
    dialogue_system = DialogueSystem(meta_learner, input_size, hidden_size, output_size)

    # Train the models
    trainer = Trainer(models, data_handler.train_loader, data_handler.val_loader, optimizers, schedulers, criterion, num_epochs)
    val_accuracy = trainer.train()

    # Test the models
    tester = Tester(models, data_handler.val_loader)
    test_accuracy = tester.test()
    print(f'Final Test Accuracy: {test_accuracy:.2f}%')

    # Ask the dialogue system for recommendations
    question = "What improvements should be made to the system?"
    performance_metrics = [test_accuracy, 0.5, 0.3, 0.2, 0.1]
    response = dialogue_system.ask_question(question, performance_metrics)
    print(f"The system recommends: {response}")

    # Apply the recommended option
    models, optimizers, schedulers = dialogue_system.apply_option(response, models, optimizers, schedulers, learning_rate, dropout_rate)

    # Retrain the models with the applied option
    trainer = Trainer(models, data_handler.train_loader, data_handler.val_loader, optimizers, schedulers, criterion, num_epochs)
    trainer.train()

if __name__ == "__main__":
    main()