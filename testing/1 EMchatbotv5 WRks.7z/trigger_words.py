# trigger_words.py

TRIGGER_WORDS = [
    # Greetings and Introductions
    "hello", "hi", "hey", "greetings", "welcome", "good", "morning", "afternoon", "evening",
    "how", "are", "you", "doing", "nice", "meet", "pleasure",

    # Questions
    "what", "where", "who", "when", "why", "how", "which", "can", "could", "would", "should",
    "is", "are", "do", "does", "did", "may", "might", "must", "shall", "will",

    # Common Conversation Topics
    "name", "from", "age", "work", "job", "hobby", "interest", "family", "friend", "time", "date",
    "today", "yesterday", "tomorrow", "weather", "help", "problem", "idea", "question",

    # Learning and Knowledge
    "learn", "teach", "study", "understand", "know", "explain", "example", "knowledge", "concept",
    "topic", "lesson", "practice", "improve", "skill", "train", "experiment",

    # Python and Programming
    "python", "code", "program", "script", "function", "variable", "loop", "condition", "if", "else",
    "class", "object", "list", "dictionary", "array", "string", "integer", "float", "boolean",
    "error", "debug", "test", "syntax", "run", "execute", "print", "define",

    # Machine Learning and AI
    "machine", "learning", "ai", "artificial", "intelligence", "model", "train", "dataset",
    "algorithm", "neural", "network", "entity", "emergent", "spike", "memory", "data", "process",
    "compute", "optimize", "accuracy", "feature", "weight", "bias",

    # User Interaction and Feedback
    "yes", "no", "okay", "ok", "sure", "thanks", "thank", "welcome", "sorry", "oops", "mistake",
    "correct", "wrong", "right", "feedback", "good", "bad", "like", "dislike",

    # Entities and Dynamic Learning
    "entity", "entities", "dynamic", "emergent", "train", "create", "generate", "scale", "adapt",
    "grow", "learn", "connect", "context", "spike", "trigger", "process",

    # Miscellaneous Topics
    "food", "music", "movie", "book", "game", "sport", "travel", "country", "language", "culture",
    "technology", "science", "space", "math", "physics", "chemistry", "biology", "history"
]