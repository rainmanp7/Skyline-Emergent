import json
from collections import Counter
import re
from typing import List, Dict

class Entity:
    def __init__(self, name: str):
        """
        Initialize an Entity.
        
        :param name: Name of the entity.
        """
        self.name = name
        self.properties: Dict[str, str] = {}  # Dictionary to store entity properties
        self.connections: List['Entity'] = []  # List to store connected entities

    def add_property(self, key: str, value: str) -> None:
        """Add a new property to the entity."""
        self.properties[key] = value

    def connect(self, other_entity: 'Entity') -> None:
        """Connect this entity to another entity."""
        if other_entity not in self.connections:
            self.connections.append(other_entity)

    def scale(self, input_text: str) -> None:
        """Scale the entity based on the input text."""
        # Add basic properties
        self.add_property("Input", input_text)
        self.add_property("WordCount", str(len(input_text.split())))

        # Extract keywords and add as properties
        keywords = self.extract_keywords(input_text)
        for i, keyword in enumerate(keywords):
            self.add_property(f"Keyword_{i + 1}", keyword)

        # Add a general topic based on keywords
        if keywords:
            self.add_property("Topic", keywords[0])
        else:
            self.add_property("Topic", "General")

    def extract_keywords(self, text: str) -> List[str]:
        """Extract keywords from the input text using a more advanced approach."""
        # Remove punctuation and convert to lowercase
        text = re.sub(r'[^\w\s]', '', text.lower())
        
        # Split into words
        words = text.split()
        
        # Define a list of stopwords to ignore
        stopwords = set([
            "a", "an", "the", "is", "are", "was", "were", "be", "been",
            "being", "have", "has", "had", "do", "does", "did", "will",
            "would", "should", "can", "could", "of", "in", "on", "at",
            "for", "to", "with", "as", "by", "about", "and", "or",
            "but", "not", "it", "this", "that", "these", "those",
            "i", "you", "he", "she", "we", "they", "me", "him",
            "her", "us", "them"
        ])
        
        # Filter out stopwords and short words
        keywords = [word for word in words if word not in stopwords and len(word) > 2]
        
        # Count word frequencies
        word_freq = Counter(keywords)
        
        # Return the top 5 most frequent keywords
        return [word for word, freq in word_freq.most_common(5)]

    def to_json(self) -> str:
        """Convert the entity to a JSON string."""
        return json.dumps({
            "name": self.name,
            "properties": self.properties,
            # Use a list comprehension to get connection names directly
            "connections": [conn.name for conn in self.connections]
        })

    @staticmethod
    def from_json(json_data: str) -> 'Entity':
        """Create an entity from a JSON string."""
        data = json.loads(json_data)
        
        # Create an Entity instance with the name from JSON data
        entity = Entity(data['name'])
        
        # Restore properties and connections from JSON data
        entity.properties = data['properties']
        
        # Create Entity instances for each connection using their names
        entity.connections = [Entity(conn) for conn in data['connections']]
        
        return entity
