import sqlite3
import logging
import json
import random
from grammar_corrector import GrammarCorrector
from entity import Entity

# Set up logging (consistent with other classes)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class ChatBot:
    def __init__(self, db_name: str = "chatbot.db"):
        """
        Initialize the ChatBot.
        
        :param db_name: Name of the SQLite database file.
        """
        self.database = self._connect_database(db_name)
        self.cursor = self.database.cursor()
        self.grammar_corrector = GrammarCorrector()
        self.context = {}  # Dictionary to store conversation context

        # Initialize the database schema
        self._initialize_database()

    def _connect_database(self, db_name: str) -> sqlite3.Connection:
        """Connect to the SQLite database and return the connection object."""
        try:
            connection = sqlite3.connect(db_name)
            logger.info("Database connection established.")
            return connection
        except sqlite3.Error as e:
            logger.error(f"Database connection failed: {e}")
            raise

    def _initialize_database(self) -> None:
        """Initialize the database schema for entities."""
        try:
            self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS entities (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                properties TEXT NOT NULL,
                connections TEXT NOT NULL
            )
            """)
            self.database.commit()
            logger.info("Database schema initialized.")
        except sqlite3.Error as e:
            logger.error(f"Failed to initialize database: {e}")
            self.database.rollback()

    def respond(self, user_input: str) -> str:
        """Process user input and generate a response."""
        try:
            # Correct grammar and spelling
            corrected_input = self.grammar_corrector.correct_grammar(user_input)
            logger.debug(f"Corrected input: {corrected_input}")

            # Update context based on user input
            self.update_context(corrected_input)

            # Dynamic Learning: Create or update entities based on input
            self.dynamic_learn(corrected_input)

            # Generate a response based on context
            response = self.generate_response(corrected_input)
            return response

        except Exception as e:
            logger.error(f"Error in respond method: {e}")
            return "Bot: I'm sorry, I encountered an error processing your request."

    def update_context(self, input_text: str) -> None:
        """Update the conversation context based on user input."""
        try:
            # Extract keywords from the input
            keywords = Entity(input_text).extract_keywords(input_text)

            # Update context with the most recent topic
            if keywords:
                self.context["topic"] = keywords[0]
                logger.debug(f"Context updated with topic: {self.context['topic']}")
        except Exception as e:
            logger.error(f"Error updating context: {e}")

    def generate_response(self, input_text: str) -> str:
        """Generate a response based on the conversation context."""
        try:
            # Check if the input refers to a previous topic
            if "it" in input_text.lower() and "topic" in self.context:
                topic = self.context["topic"]
                return f"Bot: You're asking about {topic}. Can you clarify your question?"
            else:
                return f"Bot: {input_text}"
        except Exception as e:
            logger.error(f"Error generating response: {e}")
            return "Bot: I'm having trouble understanding that."

    def dynamic_learn(self, input_text: str) -> None:
        """Dynamically learn from user input and update entities."""
        try:
            # Check if an entity for this input already exists
            self.cursor.execute("SELECT id, name, properties FROM entities WHERE name = ?", (input_text,))
            entity_data = self.cursor.fetchone()

            if entity_data:
                # Update existing entity
                entity_id, name, properties = entity_data
                entity = Entity.from_json(properties)
                entity.scale(input_text)
                self.cursor.execute("UPDATE entities SET properties = ? WHERE id = ?",
                                    (entity.to_json(), entity_id))
                entity_id_to_update = entity_id
                new_entity = None  # No new entity created

            else:
                # Create a new entity
                new_entity = Entity(input_text)
                new_entity.scale(input_text)
                self.cursor.execute("INSERT INTO entities (name, properties, connections) VALUES (?, ?, ?)",
                                    (new_entity.name, new_entity.to_json(), json.dumps([])))
                entity_id_to_update = self.cursor.lastrowid

            # Connect related entities
            keywords = new_entity.extract_keywords(input_text) if new_entity else Entity(input_text).extract_keywords(input_text)

            for keyword in keywords:
                self.cursor.execute("SELECT id, name, properties FROM entities WHERE name = ?", (keyword,))
                related_entity_data = self.cursor.fetchone()

                if related_entity_data:
                    related_entity_id, related_name, related_properties = related_entity_data
                    related_entity = Entity.from_json(related_properties)

                    if new_entity:
                        new_entity.connect(related_entity)
                    else:
                        entity.connect(related_entity)

                    connections_list = [conn.name for conn in (new_entity.connections if new_entity else entity.connections)]
                    self.cursor.execute("UPDATE entities SET connections = ? WHERE id = ?",
                                        (json.dumps(connections_list), entity_id_to_update))

            self.database.commit()
        
        except Exception as e:
            logger.error(f"Error in dynamic learning: {e}")
            self.database.rollback()

# Main loop to run the chatbot
if __name__ == "__main__":
    chatbot = ChatBot()
    while True:
        user_input = input("You: ")
        
        if user_input.lower() in ['exit', 'quit']:
            break
        
        print(chatbot.respond(user_input))
