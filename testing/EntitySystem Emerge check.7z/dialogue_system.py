from entities.emergent_entity import EmergentEntity

class DialogueSystem:
    def __init__(self, options_file="options.txt", feedback_file="feedback.txt"):
        self.options = self.load_options(options_file)
        self.feedback = self.load_feedback(feedback_file)

    def load_options(self, options_file):
        with open(options_file, "r") as file:
            return [line.strip() for line in file.readlines()]

    def load_feedback(self, feedback_file):
        feedback = {}
        try:
            with open(feedback_file, "r") as file:
                for line in file.readlines():
                    suggestion, status = line.strip().split(": ")
                    feedback[suggestion] = status
        except FileNotFoundError:
            pass
        return feedback

    def ask_question(self, question):
        # Evaluate current setup using emergent entities
        entities = [EmergentEntity() for _ in range(5)]  # Create 5 emergent entities
        suggestions = []
        for entity in entities:
            suggestions.extend(entity.evaluate())

        # Aggregate suggestions and remove duplicates
        unique_suggestions = list(set(suggestions))

        # Filter out suggestions that have been marked as "done" or "not applicable"
        filtered_suggestions = [
            suggestion for suggestion in unique_suggestions
            if suggestion not in self.feedback or self.feedback[suggestion] == "in progress"
        ]

        # Produce a consensus
        if filtered_suggestions:
            consensus = "The system recommends the following improvements to the code structure and organization:\n" + "\n".join(filtered_suggestions)
        else:
            consensus = "The system is satisfied with the current code structure and organization."

        return consensus