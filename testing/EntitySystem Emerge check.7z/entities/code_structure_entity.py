class CodeStructureEntity:
    def __init__(self, options_file="options.txt"):
        self.options = self.load_options(options_file)

    def load_options(self, options_file):
        with open(options_file, "r") as file:
            return [line.strip() for line in file.readlines()]

    def evaluate(self):
        suggestions = []
        if "Refactor into smaller functions" in self.options:
            suggestions.append("Refactor large functions into smaller, reusable functions.")
        if "Add type hints" in self.options:
            suggestions.append("Add type hints to improve code readability and maintainability.")
        if "Use design patterns" in self.options:
            suggestions.append("Consider using design patterns like Factory or Strategy for better code organization.")
        return suggestions