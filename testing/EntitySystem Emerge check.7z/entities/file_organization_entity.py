class FileOrganizationEntity:
    def __init__(self, options_file="options.txt"):
        self.options = self.load_options(options_file)

    def load_options(self, options_file):
        with open(options_file, "r") as file:
            return [line.strip() for line in file.readlines()]

    def evaluate(self):
        suggestions = []
        if "Group related files" in self.options:
            suggestions.append("Group related files into directories (e.g., `models/`, `utils/`).")
        if "Add README.md" in self.options:
            suggestions.append("Add a README.md file to document the project structure and usage.")
        if "Use config files" in self.options:
            suggestions.append("Use configuration files (e.g., `config.yaml`) to manage hyperparameters and settings.")
        return suggestions