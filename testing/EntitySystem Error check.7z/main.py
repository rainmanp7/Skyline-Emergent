from code_error_checker import CodeErrorChecker

def main():
    """
    Main function to run the code error checker and generate a report.
    """
    try:
        # Initialize the CodeErrorChecker with the current directory
        error_checker = CodeErrorChecker()

        # Debug: Print the directory being checked
        print(f"Checking directory: {error_checker.directory}")

        # Check the directory and subdirectories for errors
        error_checker.check_directory()

        # Debug: Print the number of files checked
        print(f"Number of files checked: {len(error_checker.error_counts)}")

        # Generate and print the error report
        report = error_checker.generate_report()
        print(report, flush=True)
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()