import os
import ast
from collections import defaultdict
from tqdm import tqdm  # Import tqdm for progress bar
from multiprocessing import Pool, cpu_count
from entities.emergent_entity import EmergentEntity  # Corrected import path

class CodeErrorChecker:
    def __init__(self, directory="."):
        """
        Initialize the CodeErrorChecker with the directory to check.
        :param directory: The directory to scan for Python files (default is current directory).
        """
        self.directory = directory
        self.error_counts = defaultdict(list)  # Dictionary to store errors for each file

    def check_file(self, file_path):
        """
        Check a single Python file for syntax errors, unused variables/imports, and undeclared variables.
        :param file_path: The path to the file to check.
        :return: A tuple of (file_path, list of errors).
        """
        errors = []

        # Check for syntax errors
        try:
            with open(file_path, "r", encoding="utf-8") as file:
                tree = ast.parse(file.read(), filename=file_path)
        except SyntaxError as e:
            errors.append(f"SyntaxError: {str(e)}")
            return file_path, errors  # Stop further checks if there's a syntax error
        except Exception as e:
            errors.append(f"UnexpectedError: {str(e)}")
            return file_path, errors

        # Check for unused variables and imports
        errors.extend(self._find_unused_variables_and_imports(tree, file_path))

        # Check for undeclared variables
        errors.extend(self._find_undeclared_variables(tree, file_path))

        return file_path, errors

    def _find_unused_variables_and_imports(self, tree, file_path):
        """
        Find unused variables and imports in the AST.
        :param tree: The AST of the file.
        :param file_path: The path to the file.
        :return: A list of errors related to unused variables and imports.
        """
        errors = []
        used_names = set()
        defined_names = set()

        # Traverse the AST to find defined and used names
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        defined_names.add(target.id)
            elif isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
                used_names.add(node.id)

        # Check for unused variables
        for name in defined_names:
            if name not in used_names:
                errors.append(f"UnusedVariable: Variable '{name}' is defined but never used.")

        # Check for unused imports
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name not in used_names:
                        errors.append(f"UnusedImport: Import '{alias.name}' is unused.")
            elif isinstance(node, ast.ImportFrom):
                for alias in node.names:
                    if alias.name not in used_names:
                        errors.append(f"UnusedImport: Import '{alias.name}' from '{node.module}' is unused.")

        return errors

    def _find_undeclared_variables(self, tree, file_path):
        """
        Find undeclared variables in the AST.
        :param tree: The AST of the file.
        :param file_path: The path to the file.
        :return: A list of errors related to undeclared variables.
        """
        errors = []
        defined_names = set()
        imported_names = set()

        # List of Python built-ins to ignore
        python_builtins = {
            "self", "range", "len", "print", "open", "list", "set", "str", "Exception", "super", "enumerate"
        }

        # Traverse the AST to find defined names and imports
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        defined_names.add(target.id)
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    imported_names.add(alias.name)
            elif isinstance(node, ast.ImportFrom):
                imported_names.add(node.module)

        # Check for undeclared variables
        for node in ast.walk(tree):
            if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
                if (
                    node.id not in defined_names
                    and node.id not in imported_names
                    and node.id not in python_builtins
                ):
                    errors.append(f"UndeclaredVariable: Variable '{node.id}' is used but not defined.")

        return errors

    def check_directory(self):
        """
        Recursively check all Python files in the directory and subdirectories for errors.
        """
        # Get a list of all Python files in the directory and subdirectories
        python_files = []
        for root, _, files in os.walk(self.directory):
            for file in files:
                if file.endswith(".py"):
                    python_files.append(os.path.join(root, file))

        # Debug: Print the list of Python files
        print(f"Python files found: {python_files}")

        # Use multiprocessing to process files in parallel
        with Pool(processes=cpu_count()) as pool:
            # Use tqdm to display a progress bar
            results = list(tqdm(pool.imap(self.check_file, python_files), total=len(python_files), desc="Checking files", unit="file"))

        # Collect errors from the results
        for file_path, errors in results:
            if errors:
                self.error_counts[file_path].extend(errors)

    def generate_report(self):
        """
        Generate a report of files with errors, sorted by the number of errors.
        :return: A formatted report string.
        """
        if not self.error_counts:
            return "No errors found in any Python files."

        # Sort files by the number of errors in descending order
        sorted_files = sorted(self.error_counts.items(), key=lambda x: len(x[1]), reverse=True)

        # Generate the report
        report = "Files with errors:\n"
        for file_path, errors in sorted_files:
            report += f"\n{file_path}:\n"
            for error in errors:
                report += f"  - {error}\n"

        # Add emergent entity suggestions
        emergent_suggestions = self._get_emergent_suggestions()
        if emergent_suggestions:
            report += "\nEmergent Entity Suggestions:\n"
            for suggestion in emergent_suggestions:
                report += f"  - {suggestion}\n"

        return report

    def _get_emergent_suggestions(self):
        """
        Get suggestions from emergent entities.
        :return: A list of unique suggestions.
        """
        # Create 5 emergent entities
        entities = [EmergentEntity() for _ in range(5)]

        # Collect suggestions from all entities
        suggestions = []
        for entity in entities:
            suggestions.extend(entity.evaluate())

        # Remove duplicate suggestions and empty strings
        unique_suggestions = list(set(suggestions))
        unique_suggestions = [s for s in unique_suggestions if s.strip()]

        return unique_suggestions