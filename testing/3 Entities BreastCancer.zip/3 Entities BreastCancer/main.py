import torch
from torch import nn, optim
from torch.utils.data import DataLoader
from models import SimpleRNN, SimpleCNN, SimpleSNN, EmergentSystem
from dataset import BreastCancerDataset
from train import train, test

def initialize_optimizers(models, learning_rate, weight_decay=0.0):
    optimizers = [
        optim.Adam(models[0].parameters(), lr=learning_rate, weight_decay=weight_decay),
        optim.Adam(models[1].parameters(), lr=learning_rate, weight_decay=weight_decay),
        optim.Adam(models[2].parameters(), lr=learning_rate, weight_decay=weight_decay)
    ]
    return optimizers

def main():
    # Parameters
    input_size = 30  # Number of features in Breast Cancer dataset
    hidden_size = 20
    output_size = 2  # Binary classification
    num_steps = 10
    batch_size = 32
    num_epochs = 35
    learning_rate = 0.001
    dropout_rate = 0.5

    # Initialize models
    rnn = SimpleRNN(input_size, hidden_size, output_size, dropout_rate)
    cnn = SimpleCNN(input_size, output_size, dropout_rate)
    snn_model = SimpleSNN(input_size, output_size, num_steps, dropout_rate)
    models = [rnn, cnn, snn_model]

    # Create dataset and dataloaders
    train_dataset = BreastCancerDataset(train=True)
    val_dataset = BreastCancerDataset(train=False)
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)

    # Define loss function and optimizers
    criterion = nn.CrossEntropyLoss()
    optimizers = initialize_optimizers(models, learning_rate)
    schedulers = []  # Initialize schedulers as an empty list

    # Train models
    print("Initial Training...")
    val_accuracy = train(models, train_loader, val_loader, optimizers, schedulers, criterion, num_epochs)

    # Test models
    test_accuracy = test(models, val_loader)
    print(f'Initial Test Accuracy: {test_accuracy:.2f}%')

if __name__ == "__main__":
    main()