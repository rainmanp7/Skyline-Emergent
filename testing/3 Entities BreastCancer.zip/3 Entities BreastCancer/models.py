import torch
from torch import nn

class SimpleRNN(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, dropout_rate=0.5):
        super(SimpleRNN, self).__init__()
        self.rnn = nn.RNN(input_size, hidden_size, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        # Add a sequence dimension for RNN
        x = x.unsqueeze(1)
        h_0 = torch.zeros(1, x.size(0), self.rnn.hidden_size)
        out, _ = self.rnn(x, h_0)
        out = self.fc(out[:, -1, :])
        return out

class SimpleCNN(nn.Module):
    def __init__(self, input_size, output_size, dropout_rate=0.5):
        super(SimpleCNN, self).__init__()
        self.conv1 = nn.Conv1d(1, 16, kernel_size=3, stride=1, padding=1)
        self.relu = nn.ReLU()
        self.pool = nn.MaxPool1d(kernel_size=2, stride=2, padding=0)
        self.fc = nn.Linear(16 * (input_size // 2), output_size)
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        x = x.unsqueeze(1)  # Add channel dimension
        x = self.pool(self.relu(self.conv1(x)))
        x = x.view(x.size(0), -1)
        x = self.dropout(x)
        x = self.fc(x)
        return x

class SimpleSNN(nn.Module):
    def __init__(self, input_size, output_size, num_steps, dropout_rate=0.5):
        super(SimpleSNN, self).__init__()
        self.num_steps = num_steps
        self.fc1 = nn.Linear(input_size, 50)
        self.fc2 = nn.Linear(50, output_size)
        self.spike_threshold = 1.0
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        batch_size = x.size(0)
        x = x.unsqueeze(1).repeat(1, self.num_steps, 1)
        v_mem = torch.zeros(batch_size, 50)
        for step in range(self.num_steps):
            cur = self.fc1(x[:, step])
            v_mem += cur
            spikes = (v_mem > self.spike_threshold).float()
            v_mem = v_mem * (1 - spikes)
        out = self.fc2(v_mem)
        return out

class EmergentSystem(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, num_steps, dropout_rate=0.5):
        super(EmergentSystem, self).__init__()
        self.rnn_entity = SimpleRNN(input_size, hidden_size, hidden_size, dropout_rate)
        self.cnn_entity = SimpleCNN(input_size, hidden_size, dropout_rate)
        self.snn_entity = SimpleSNN(input_size, hidden_size, num_steps, dropout_rate)
        self.communication_layer = nn.Linear(hidden_size * 3, hidden_size * 3)
        self.fc = nn.Linear(hidden_size * 3, output_size)

    def forward(self, x):
        rnn_output = self.rnn_entity(x)
        cnn_output = self.cnn_entity(x)
        snn_output = self.snn_entity(x)
        combined_outputs = torch.cat([rnn_output, cnn_output, snn_output], dim=1)
        communicated_outputs = self.communication_layer(combined_outputs)
        out = self.fc(communicated_outputs)
        return out