import torch
from torch import nn
from torch.optim.lr_scheduler import CyclicLR, StepLR, ReduceLROnPlateau
from models import SimpleRNN, SimpleRNNWithAttention, SimpleCNN, SimpleSNN

class MetaLearner(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(MetaLearner, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, output_size)
        self.relu = nn.ReLU()
        self.softmax = nn.Softmax(dim=0)  # Add softmax activation

    def forward(self, x):
        x = self.relu(self.fc1(x))
        x = self.fc2(x)
        x = self.softmax(x)  # Apply softmax to output
        return x

class DialogueSystem:
    def __init__(self, meta_learner, options_file="options.txt"):
        self.meta_learner = meta_learner
        self.options = self.load_options(options_file)

    def load_options(self, options_file):
        with open(options_file, "r") as file:
            options = [line.strip() for line in file.readlines()]
        return options

    def ask_question(self, question, performance_metrics):
        # Convert question and performance metrics to input tensor
        input_tensor = torch.tensor(performance_metrics, dtype=torch.float32)
        response = self.meta_learner(input_tensor)
        
        # Map response to human-readable suggestions
        selected_option = self.options[torch.argmax(response).item()]
        return selected_option

    def apply_option(self, option, models, optimizers, schedulers, learning_rate, dropout_rate, input_size, hidden_size, output_size):
        if "Add Multi-Head Attention" in option:
            num_heads = int(option.split()[-2])  # Extract number of heads
            models[0] = SimpleRNNWithAttention(input_size, hidden_size, output_size, num_heads=num_heads, dropout_rate=dropout_rate)
        elif "Use cyclical learning rate" in option:
            base_lr = float(option.split("base_lr=")[1].split(",")[0])
            max_lr = float(option.split("max_lr=")[1])
            schedulers = self.initialize_schedulers(optimizers, "CyclicLR", base_lr=base_lr, max_lr=max_lr, step_size_up=2000, mode='triangular2')
        elif "Add batch normalization" in option:
            # Add batch normalization to models
            for model in models:
                if isinstance(model, SimpleRNN):
                    model.rnn = nn.Sequential(
                        model.rnn,
                        nn.BatchNorm1d(model.rnn.hidden_size)
                    )
                elif isinstance(model, SimpleCNN):
                    model.conv1 = nn.Sequential(
                        model.conv1,
                        nn.BatchNorm2d(16)
                    )
                elif isinstance(model, SimpleSNN):
                    model.fc1 = nn.Sequential(
                        model.fc1,
                        nn.BatchNorm1d(50)
                    )
        # Add more options as needed
        return models, optimizers, schedulers

    def initialize_schedulers(self, optimizers, scheduler_type, **kwargs):
        schedulers = []
        for optimizer in optimizers:
            if scheduler_type == "CyclicLR":
                schedulers.append(CyclicLR(optimizer, **kwargs))
            elif scheduler_type == "StepLR":
                schedulers.append(StepLR(optimizer, **kwargs))
            elif scheduler_type == "ReduceLROnPlateau":
                schedulers.append(ReduceLROnPlateau(optimizer, **kwargs))
            else:
                schedulers.append(None)  # No scheduler
        return schedulers