import torch
from torch import nn

class SimpleRNN(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, dropout_rate=0.5):
        super(SimpleRNN, self).__init__()
        self.rnn = nn.RNN(input_size, hidden_size, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        h_0 = torch.zeros(1, x.size(0), self.rnn.hidden_size)
        out, _ = self.rnn(x, h_0)
        out = self.fc(out[:, -1, :])
        return out

class SimpleRNNWithAttention(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, num_heads=4, dropout_rate=0.5):
        super(SimpleRNNWithAttention, self).__init__()
        self.rnn = nn.RNN(input_size, hidden_size, batch_first=True)
        self.attention = nn.MultiheadAttention(hidden_size, num_heads, dropout=dropout_rate)
        self.fc = nn.Linear(hidden_size, output_size)
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        h_0 = torch.zeros(1, x.size(0), self.rnn.hidden_size)
        rnn_out, _ = self.rnn(x, h_0)  # RNN output: [batch_size, seq_len, hidden_size]
        
        # Reshape for MultiheadAttention (seq_len, batch_size, hidden_size)
        rnn_out = rnn_out.permute(1, 0, 2)
        attn_out, _ = self.attention(rnn_out, rnn_out, rnn_out)  # Apply self-attention
        attn_out = attn_out.permute(1, 0, 2)  # Reshape back to [batch_size, seq_len, hidden_size]
        
        # Use the last time step's output for classification
        out = self.fc(attn_out[:, -1, :])
        return out

class SimpleCNN(nn.Module):
    def __init__(self, input_channels, output_size, dropout_rate=0.5):
        super(SimpleCNN, self).__init__()
        self.conv1 = nn.Conv2d(input_channels, 16, kernel_size=3, stride=1, padding=1)
        self.relu = nn.ReLU()
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2, padding=0)
        self.fc = nn.Linear(16 * 8 * 8, output_size)
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        x = self.pool(self.relu(self.conv1(x)))
        x = x.view(-1, 16 * 8 * 8)
        x = self.dropout(x)
        x = self.fc(x)
        return x

class SimpleSNN(nn.Module):
    def __init__(self, input_size, output_size, num_steps, dropout_rate=0.5):
        super(SimpleSNN, self).__init__()
        self.num_steps = num_steps
        self.fc1 = nn.Linear(input_size, 50)
        self.fc2 = nn.Linear(50, output_size)
        self.spike_threshold = 1.0  # Threshold for spiking
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        batch_size = x.size(0)
        if len(x.size()) == 2:  # If input is [batch_size, input_size]
            x = x.unsqueeze(1).repeat(1, self.num_steps, 1)  # Add timestep dimension
        
        # Initialize membrane potential
        v_mem = torch.zeros(batch_size, 50)
        
        # Simulate spiking behavior
        for step in range(self.num_steps):
            cur = self.fc1(x[:, step])
            v_mem += cur
            spikes = (v_mem > self.spike_threshold).float()  # Generate spikes
            v_mem = v_mem * (1 - spikes)  # Reset membrane potential for spiked neurons
        
        out = self.fc2(v_mem)
        return out

class EmergentSystem(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, num_steps, dropout_rate=0.5):
        super(EmergentSystem, self).__init__()
        # Define three distinct networks
        self.rnn_entity = SimpleRNN(input_size, hidden_size, hidden_size, dropout_rate)
        self.cnn_entity = SimpleCNN(input_channels=1, output_size=hidden_size, dropout_rate=dropout_rate)
        self.snn_entity = SimpleSNN(input_size, hidden_size, num_steps, dropout_rate)
        
        # Communication layer to combine outputs
        self.communication_layer = nn.Linear(hidden_size * 3, hidden_size * 3)
        self.fc = nn.Linear(hidden_size * 3, output_size)

    def forward(self, x):
        # Each entity processes the input independently
        rnn_output = self.rnn_entity(x)
        
        # Reshape input for CNN (assuming input is [batch_size, seq_len, input_size])
        batch_size, seq_len, input_size = x.shape
        cnn_input = x.view(batch_size * seq_len, 1, int(input_size**0.5), int(input_size**0.5))  # Reshape to [batch_size * seq_len, 1, sqrt(input_size), sqrt(input_size)]
        cnn_output = self.cnn_entity(cnn_input)
        cnn_output = cnn_output.view(batch_size, seq_len, -1)  # Reshape back to [batch_size, seq_len, hidden_size]
        
        snn_output = self.snn_entity(x[:, 0, :])  # Use first time step for SNN
        
        # Combine outputs for communication
        combined_outputs = torch.cat([rnn_output, cnn_output[:, -1, :], snn_output], dim=1)
        
        # Communication between entities
        communicated_outputs = self.communication_layer(combined_outputs)
        
        # Final output after communication
        out = self.fc(communicated_outputs)
        return out