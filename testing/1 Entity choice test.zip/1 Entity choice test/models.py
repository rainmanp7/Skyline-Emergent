import torch
from torch import nn

class SimpleRNN(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, dropout_rate=0.5):
        super(SimpleRNN, self).__init__()
        self.rnn = nn.RNN(input_size, hidden_size, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        h_0 = torch.zeros(1, x.size(0), self.rnn.hidden_size)
        out, _ = self.rnn(x, h_0)
        out = self.fc(out[:, -1, :])
        return out

class SimpleRNNWithAttention(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, num_heads=4, dropout_rate=0.5):
        super(SimpleRNNWithAttention, self).__init__()
        self.rnn = nn.RNN(input_size, hidden_size, batch_first=True)
        self.attention = nn.MultiheadAttention(hidden_size, num_heads, dropout=dropout_rate)
        self.fc = nn.Linear(hidden_size, output_size)
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        h_0 = torch.zeros(1, x.size(0), self.rnn.hidden_size)
        rnn_out, _ = self.rnn(x, h_0)  # RNN output: [batch_size, seq_len, hidden_size]
        
        # Reshape for MultiheadAttention (seq_len, batch_size, hidden_size)
        rnn_out = rnn_out.permute(1, 0, 2)
        attn_out, _ = self.attention(rnn_out, rnn_out, rnn_out)  # Apply self-attention
        attn_out = attn_out.permute(1, 0, 2)  # Reshape back to [batch_size, seq_len, hidden_size]
        
        # Use the last time step's output for classification
        out = self.fc(attn_out[:, -1, :])
        return out

class SimpleCNN(nn.Module):
    def __init__(self, input_channels, output_size, dropout_rate=0.5):
        super(SimpleCNN, self).__init__()
        self.conv1 = nn.Conv2d(input_channels, 16, kernel_size=3, stride=1, padding=1)
        self.relu = nn.ReLU()
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2, padding=0)
        self.fc = nn.Linear(16 * 8 * 8, output_size)  # Reduced size
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        x = self.pool(self.relu(self.conv1(x)))
        x = x.view(-1, 16 * 8 * 8)
        x = self.dropout(x)
        x = self.fc(x)
        return x

class SimpleSNN(nn.Module):
    def __init__(self, input_size, output_size, num_steps, dropout_rate=0.5):
        super(SimpleSNN, self).__init__()
        self.num_steps = num_steps
        self.fc1 = nn.Linear(input_size, 50)  # Reduced size
        self.fc2 = nn.Linear(50, output_size)
        self.spike_threshold = 1.0
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        batch_size = x.size(0)
        if len(x.size()) == 2:  # If input is [batch_size, input_size]
            x = x.unsqueeze(1).repeat(1, self.num_steps, 1)  # Add timestep dimension
        
        v_mem = torch.zeros(batch_size, 50)
        for step in range(self.num_steps):
            cur = self.fc1(x[:, step])
            v_mem += cur
            spikes = (v_mem > self.spike_threshold).float()
            v_mem = v_mem * (1 - spikes)
        out = self.fc2(v_mem)
        return out