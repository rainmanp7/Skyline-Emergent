import torch
from torch import nn
from torch import optim
from torch.utils.data import DataLoader
from models import SimpleRNN, SimpleRNNWithAttention, SimpleCNN, SimpleSNN
from dataset import SyntheticDataset
from train import train, test
from dialogue_system import MetaLearner, DialogueSystem
from torch.optim.lr_scheduler import CyclicLR, StepLR, ReduceLROnPlateau

def initialize_optimizers(models, learning_rate, weight_decay=0.0):
    optimizers = [
        optim.Adam(models[0].parameters(), lr=learning_rate, weight_decay=weight_decay),
        optim.Adam(models[1].parameters(), lr=learning_rate, weight_decay=weight_decay),
        optim.Adam(models[2].parameters(), lr=learning_rate, weight_decay=weight_decay)
    ]
    return optimizers

def initialize_schedulers(optimizers, scheduler_type, **kwargs):
    schedulers = []
    for optimizer in optimizers:
        if scheduler_type == "CyclicLR":
            schedulers.append(CyclicLR(optimizer, **kwargs))
        elif scheduler_type == "StepLR":
            schedulers.append(StepLR(optimizer, **kwargs))
        elif scheduler_type == "ReduceLROnPlateau":
            schedulers.append(ReduceLROnPlateau(optimizer, **kwargs))
        else:
            schedulers.append(None)  # No scheduler
    return schedulers

def main():
    # Parameters
    input_size = 10
    hidden_size = 20
    output_size = 2  # Binary classification
    num_steps = 10
    num_samples = 1000  # Larger dataset
    seq_len = 5
    cnn_input_size = 16  # Smaller input size
    batch_size = 32
    num_epochs = 35
    learning_rate = 0.001
    dropout_rate = 0.5  # Default dropout rate

    # Initialize models
    rnn = SimpleRNN(input_size, hidden_size, output_size, dropout_rate=dropout_rate)
    cnn = SimpleCNN(input_channels=1, output_size=output_size, dropout_rate=dropout_rate)
    snn_model = SimpleSNN(input_size, output_size, num_steps, dropout_rate=dropout_rate)
    models = [rnn, cnn, snn_model]

    # Create dataset and dataloaders
    train_dataset = SyntheticDataset(num_samples, input_size, seq_len, output_size, cnn_input_size)
    val_dataset = SyntheticDataset(num_samples // 5, input_size, seq_len, output_size, cnn_input_size)  # Validation set
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)

    # Define loss function and optimizers
    criterion = nn.CrossEntropyLoss()
    optimizers = initialize_optimizers(models, learning_rate)
    schedulers = initialize_schedulers(optimizers, None)  # No scheduler initially

    # Initialize Meta-Learner and Dialogue System
    meta_learner = MetaLearner(input_size=5, hidden_size=10, output_size=len(DialogueSystem([]).options))
    dialogue_system = DialogueSystem(meta_learner)

    # Train models
    val_accuracy = train(models, train_loader, val_loader, optimizers, schedulers, criterion, num_epochs)

    # Test models
    test_accuracy = test(models, val_loader)
    print(f'Final Test Accuracy: {test_accuracy:.2f}%')

    # Example question and performance metrics
    question = "What improvements should be made to the system?"
    performance_metrics = [test_accuracy, 0.5, 0.3, 0.2, 0.1]  # Example metrics

    # Get response from the system
    response = dialogue_system.ask_question(question, performance_metrics)
    print(f"The system recommends: {response}")

    # Apply the recommendation
    models, optimizers, schedulers = dialogue_system.apply_option(response, models, optimizers, schedulers, learning_rate, dropout_rate)

    # Retrain models with the adjusted configuration
    train(models, train_loader, val_loader, optimizers, schedulers, criterion, num_epochs)

if __name__ == "__main__":
    main()