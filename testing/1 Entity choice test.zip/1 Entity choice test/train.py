
import torch
from torch.optim.lr_scheduler import CyclicLR, StepLR, ReduceLROnPlateau

def train(models, train_loader, val_loader, optimizers, schedulers, criterion, num_epochs, patience=5):
    best_val_accuracy = 0.0
    epochs_no_improve = 0

    for epoch in range(num_epochs):
        # Training
        for i, (rnn_inputs, cnn_inputs, labels) in enumerate(train_loader):
            for optimizer in optimizers:
                optimizer.zero_grad()

            rnn_output = models[0](rnn_inputs)
            cnn_output = models[1](cnn_inputs)
            snn_output = models[2](rnn_inputs[:, 0, :])  # Use first time step for SNN

            outputs = [rnn_output, cnn_output, snn_output]
            consensus = torch.mean(torch.stack(outputs), dim=0)

            loss = criterion(consensus, labels)
            loss.backward()
            for optimizer in optimizers:
                optimizer.step()

            # Update schedulers
            for scheduler in schedulers:
                if scheduler is not None:
                    scheduler.step()

        # Validation
        val_accuracy = test(models, val_loader)
        print(f'Epoch [{epoch+1}/{num_epochs}], Loss: {loss.item():.4f}, Val Accuracy: {val_accuracy:.2f}%')

        # Early stopping
        if val_accuracy > best_val_accuracy:
            best_val_accuracy = val_accuracy
            epochs_no_improve = 0
        else:
            epochs_no_improve += 1
            if epochs_no_improve == patience:
                print(f'Early stopping triggered after {epoch+1} epochs.')
                break

    return val_accuracy

def test(models, test_loader):
    with torch.no_grad():
        correct = 0
        total = 0
        for rnn_inputs, cnn_inputs, labels in test_loader:
            rnn_output = models[0](rnn_inputs)
            cnn_output = models[1](cnn_inputs)
            snn_output = models[2](rnn_inputs[:, 0, :])  # Use first time step for SNN

            outputs = [rnn_output, cnn_output, snn_output]
            consensus = torch.mean(torch.stack(outputs), dim=0)

            _, predicted = torch.max(consensus.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

        return 100 * correct / total