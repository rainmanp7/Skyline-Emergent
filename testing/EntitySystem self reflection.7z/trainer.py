import torch
from tester import Tester

class Trainer:
    def __init__(self, models, train_loader, val_loader, optimizers, schedulers, criterion, num_epochs, patience=5):
        self.models = models
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.optimizers = optimizers
        self.schedulers = schedulers
        self.criterion = criterion
        self.num_epochs = num_epochs
        self.patience = patience

    def train(self):
        best_val_accuracy = 0.0
        epochs_no_improve = 0

        for epoch in range(self.num_epochs):
            for i, (rnn_inputs, cnn_inputs, labels) in enumerate(self.train_loader):
                for optimizer in self.optimizers:
                    optimizer.zero_grad()

                rnn_output = self.models[0](rnn_inputs)
                cnn_output = self.models[1](cnn_inputs)
                snn_output = self.models[2](rnn_inputs[:, 0, :])

                outputs = [rnn_output, cnn_output, snn_output]
                consensus = torch.mean(torch.stack(outputs), dim=0)

                loss = self.criterion(consensus, labels)
                loss.backward()
                for optimizer in self.optimizers:
                    optimizer.step()

                for scheduler in self.schedulers:
                    if scheduler is not None:
                        scheduler.step()

            val_accuracy = Tester(self.models, self.val_loader).test()
            print(f'Epoch [{epoch+1}/{self.num_epochs}], Loss: {loss.item():.4f}, Val Accuracy: {val_accuracy:.2f}%')

            if val_accuracy > best_val_accuracy:
                best_val_accuracy = val_accuracy
                epochs_no_improve = 0
            else:
                epochs_no_improve += 1
                if epochs_no_improve == self.patience:
                    print(f'Early stopping triggered after {epoch+1} epochs.')
                    break

        return val_accuracy