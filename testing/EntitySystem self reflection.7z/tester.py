import torch

class Tester:
    def __init__(self, models, test_loader):
        self.models = models
        self.test_loader = test_loader

    def test(self):
        with torch.no_grad():
            correct = 0
            total = 0
            for rnn_inputs, cnn_inputs, labels in self.test_loader:
                rnn_output = self.models[0](rnn_inputs)
                cnn_output = self.models[1](cnn_inputs)
                snn_output = self.models[2](rnn_inputs[:, 0, :])

                outputs = [rnn_output, cnn_output, snn_output]
                consensus = torch.mean(torch.stack(outputs), dim=0)

                _, predicted = torch.max(consensus.data, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()

            return 100 * correct / total