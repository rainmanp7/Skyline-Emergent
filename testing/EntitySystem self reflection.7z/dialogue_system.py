from entities.code_structure_entity import CodeStructureEntity
from entities.modularity_entity import ModularityEntity
from entities.file_organization_entity import FileOrganizationEntity
from entities.best_practices_entity import BestPracticesEntity

class DialogueSystem:
    def __init__(self, options_file="options.txt"):
        self.options = self.load_options(options_file)

    def load_options(self, options_file):
        with open(options_file, "r") as file:
            return [line.strip() for line in file.readlines()]

    def ask_question(self, question):
        # Evaluate current setup using entities
        code_structure_entity = CodeStructureEntity()
        modularity_entity = ModularityEntity()
        file_organization_entity = FileOrganizationEntity()
        best_practices_entity = BestPracticesEntity()

        # Get suggestions from all entities
        suggestions = (
            code_structure_entity.evaluate()
            + modularity_entity.evaluate()
            + file_organization_entity.evaluate()
            + best_practices_entity.evaluate()
        )

        # Produce a consensus
        if suggestions:
            consensus = "The system recommends the following improvements to the code structure and organization:\n" + "\n".join(suggestions)
        else:
            consensus = "The system is satisfied with the current code structure and organization."

        return consensus