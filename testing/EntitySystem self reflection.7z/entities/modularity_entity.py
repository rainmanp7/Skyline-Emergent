class ModularityEntity:
    def __init__(self, options_file="options.txt"):
        self.options = self.load_options(options_file)

    def load_options(self, options_file):
        with open(options_file, "r") as file:
            return [line.strip() for line in file.readlines()]

    def evaluate(self):
        suggestions = []
        if "Separate concerns" in self.options:
            suggestions.append("Separate concerns by dividing code into modules with single responsibilities.")
        if "Use dependency injection" in self.options:
            suggestions.append("Use dependency injection to reduce coupling between modules.")
        if "Add interfaces" in self.options:
            suggestions.append("Add interfaces to define clear contracts between modules.")
        return suggestions