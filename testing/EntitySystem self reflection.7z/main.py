from dialogue_system import DialogueSystem

def main():
    # Initialize DialogueSystem
    dialogue_system = DialogueSystem()

    # Ask the dialogue system for an introspective look at the code structure
    question = "How can we improve the code structure and organization?"
    consensus = dialogue_system.ask_question(question)
    print(consensus)

if __name__ == "__main__":
    main()